Javadoc can be found: Assignment 7\superheroes\src\main\resources\static\doc\index.html
