javadoc can be found at:

AssignmentSix\guessGame\src\main\resources\static\index.html