use thewileyhotel;

INSERT INTO Guest VALUES (
  12,
  "+447959296786",
  "David Akinsanya"
);

INSERT INTO Address VALUES (
  12,
  "67 Drill Street", 
  "Edmonton Green", 
  "HK", 
  "67674"
); 
